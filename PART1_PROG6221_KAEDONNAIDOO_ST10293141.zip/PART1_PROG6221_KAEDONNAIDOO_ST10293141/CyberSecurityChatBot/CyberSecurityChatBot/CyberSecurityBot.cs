﻿using System;
using System.Media;
using System.Threading;

namespace CyberSecurityChatBot
{
    class CyberSecurityBot
    {
        private string userName; // Stores the user's name for personalization

        // Method to play the voice greeting when the chatbot starts
        public void PlayVoiceGreeting()
        {
            try
            {
                SoundPlayer player = new SoundPlayer("audio.wav"); // Load the WAV file
                player.Load();
                player.PlaySync(); // Play synchronously so the audio finishes before continuing
            }
            catch (Exception ex)
            {
                // Error handling in case audio fails to play
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Error playing audio: " + ex.Message);
                Console.ResetColor();
            }
        }

        // Method to display ASCII art/logo for the chatbot
        public void DisplayAsciiLogo()
        {
            Console.ForegroundColor = ConsoleColor.Cyan; // Set text color
            Console.WriteLine(@"
   ____           _              ____        _   
  / ___|___ _ __ | |_ ___ _ __  | __ )  ___ | |_ 
 | |   / _ \ '_ \| __/ _ \ '__| |  _ \ / _ \| __|
 | |__|  __/ | | | ||  __/ |    | |_) | (_) | |_ 
  \____\___|_| |_|\__\___|_|    |____/ \___/ \__|
                                                 
            Cybersecurity Awareness Bot
");
            Console.ResetColor(); // Reset to default color
        }

        // Method to ask user for their name and greet them
        public void GreetUser()
        {
            Console.Write("\nPlease enter your name: ");
            userName = Console.ReadLine();

            // Validate input to prevent empty or whitespace-only names
            while (string.IsNullOrWhiteSpace(userName))
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("Name cannot be empty. Please enter your name: ");
                Console.ResetColor();
                userName = Console.ReadLine();
            }

            // Personalized greeting
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nWelcome, {userName}! I’m your Cybersecurity Awareness Assistant.");
            Console.ResetColor();
        }

        // Main chat interaction loop
        public void StartChat()
        {
            Console.WriteLine("\n   Type help for me the explain what i can do or type 'exit' to leave the chat.\n");

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("You: ");
                Console.ResetColor();

                string input = Console.ReadLine().ToLower().Trim(); // Read and normalize input

                // Handle empty or invalid input
                if (string.IsNullOrWhiteSpace(input))
                {
                    ShowResponse("I didn't quite understand that. Could you rephrase?");
                    continue;
                }

                // Exit condition
                if (input == "exit")
                {
                    ShowResponse("Stay safe online, goodbye!");
                    break;
                }

                // Match known input and respond appropriately
                switch (input)
                {
                    case "help":
                        ShowResponse("Hello, I can help you with password safety, phishing attacks, tips on creating a strong password and safe browsing tips.");
                        break;
                    case "how are you":
                        ShowResponse("I'm functioning securely and ready to help you stay safe online!");
                        break;
                    case "what's your purpose":
                        ShowResponse("I'm here to teach you about cybersecurity and how to avoid online threats.");
                        break;
                    case "what can i ask you about":
                        ShowResponse("You can ask me about password safety, phishing, safe browsing, and more.");
                        break;
                    case "phishing":
                        ShowResponse("Phishing is a scam where attackers trick you into giving away sensitive info. Watch out for suspicious emails or links!");
                        break;
                    case "password":
                        ShowResponse("Use a mix of uppercase, lowercase, numbers, and special characters. Avoid using obvious words like 'password123'.");
                        break;
                    case "safe browsing":
                        ShowResponse("Safe browsing means avoiding suspicious websites, not clicking on unknown links, and using secure HTTPS connections.");
                        break;
                    default:
                        // Default response for unrecognized input
                        ShowResponse("I'm still learning! Try asking me about phishing, password safety, or safe browsing.");
                        break;
                }
            }
        }

        // Helper method to display bot responses with typing effect
        private void ShowResponse(string message)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(20); // Creates typing animation by delaying each character
            }
            Console.WriteLine();
            Console.ResetColor();
        }
    }
}

//https://github.com/readme/guides/sothebys-github-actions
//https://www.w3schools.com/cs/index.php
//https://elevenlabs.io/
