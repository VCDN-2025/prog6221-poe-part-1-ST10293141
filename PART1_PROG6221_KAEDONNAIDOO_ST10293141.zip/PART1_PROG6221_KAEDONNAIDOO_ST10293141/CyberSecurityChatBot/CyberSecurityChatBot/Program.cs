﻿namespace CyberSecurityChatBot
{
    class Program
    {
        static void Main(string[] args)
        {
            // Instantiate the bot
            CyberSecurityBot bot = new CyberSecurityBot();

            // Call methods in sequence
            bot.PlayVoiceGreeting();     // Step 1: Audio greeting
            bot.DisplayAsciiLogo();      // Step 2: Show ASCII art
            bot.GreetUser();             // Step 3: Ask user's name
            bot.StartChat();             // Step 4: Start chatbot conversation
        }
    }
}

//https://github.com/readme/guides/sothebys-github-actions
//https://www.w3schools.com/cs/index.php
//https://elevenlabs.io/
